# Atlas Relics website v2

Next.js (App Router) + TypeScript + Tailwind scaffold for the Atlas Relics companion experience: **The Caves**, **Shadow Ledger**, **Conscious Mirror**, and **Wisdom Drop**.

Content is loaded from the structured content pack under `content/` — confirmed fields are shown as-is; `needs_content` placeholders are visible in the UI and are **intentional**.

## Setup

```bash
cd Atlas-Relics-website-v2
npm install
npm run dev      # http://localhost:3000
npm run build    # production build
npm start        # serve production build
```

Requirements: Node.js 20+ recommended.

## Stack

- Next.js 15+ App Router (scaffold from `create-next-app@latest`)
- TypeScript
- Tailwind CSS v4
- Content: static JSON imports from `content/data`

## Routes

| Path | Purpose |
|------|---------|
| `/` | Landing with CTAs to all four pillars |
| `/caves` | List of caves |
| `/caves/[id]` | Cave detail (phases, core questions, placeholders) |
| `/ledger` | Shadow Ledger archetypes |
| `/ledger/[id]` | Archetype + polarity + integration ritual |
| `/mirror` | Conscious Mirror flow (intake + reading sections; no LLM) |
| `/wisdom` | Wisdom Drop entries (handles empty/placeholder rows) |

Shared header/footer live in `components/`.

## Content model

```
content/
  data/          # Runtime JSON (copied from atlas-relics-app-content)
    caves.json
    archetypes.json
    ledger_prompts.json
    wisdom_entries.json
    mirror_reading_structure.json
  schema/        # JSON Schema for editors / validation
```

TypeScript shapes are in `lib/types.ts`. Loaders/helpers are in `lib/content.ts`.

### Status fields

Every content object (except the Mirror structure root) includes:

- `"status": "confirmed"` — from real Atlas Relics product content
- `"status": "needs_content"` — schema slot reserved; **do not invent product copy**

The UI surfaces these with badges and dashed “Content pending” callouts.

## How to expand content

1. Edit the matching file under `content/data/` (or update the upstream content pack and re-copy).
2. Keep field names aligned with `content/schema/*.schema.json`.
3. When text is ready, set `"status": "confirmed"` and fill previously `null` fields.
4. For Wisdom Drop: add one object per law/truth; set `source` to `"Laws of the Universe"`, `"Ageless Truths"`, `"The Great Shift"`, or `"other"`.
5. For ledger polarity: set `polarity_partner_id` to another archetype’s `id`.
6. For rituals: fill `practice_type` and `text` on the matching `ledger_prompts.json` row.
7. Run `npm run build` to confirm types and static generation still pass.

**Do not invent** Laws of the Universe lines, archetype descriptions, or Cave phase prose under the Atlas Relics name. Leave `needs_content` until source material is supplied.

## Caveats

- Package name in `package.json` is lowercase (`atlas-relics-website-v2`) due to npm naming rules; the project folder may use mixed case.
- Mirror page explains the flow and lists intake questions; it does **not** call an LLM or accept submissions.
- Dynamic routes use `generateStaticParams` from the JSON IDs.

## License / ownership

Product content belongs to Atlas Relics. This scaffold is a presentation shell only.
