import Link from "next/link";
import { caves } from "@/lib/content";
import { SHOP_URL } from "@/lib/types";

const FIRST_DESCENT_LEDE =
  "Begin your first descent with three guided philosophical experiences exploring control, desire, and identity, created to reveal what quietly shapes the way you think, want, and see yourself.";

/** Bundle spotlight: Desire, Identity, Control (as on the live shop) */
const bundleIds = ["cave-of-desire", "cave-of-identity", "cave-of-control"];

export default function HomePage() {
  const bundleCaves = bundleIds
    .map((id) => caves.find((c) => c.id === id))
    .filter(Boolean);

  return (
    <>
      {/* Hero — The First Descent */}
      <section className="hero" aria-label="The First Descent">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src="/brand/hero-first-descent.jpg"
          alt=""
          className="hero-bg"
        />
        <div className="hero-overlay" />
        <div className="hero-content">
          <h1 className="hero-title">The First Descent</h1>
          <p className="hero-lede">{FIRST_DESCENT_LEDE}</p>
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <Link href="/caves" className="btn-primary">
              Begin Your Descent
            </Link>
            <a
              href={SHOP_URL}
              className="btn-secondary"
              target="_blank"
              rel="noopener noreferrer"
            >
              Buy Now
            </a>
          </div>
        </div>
      </section>

      {/* Bundle includes */}
      <section className="section-block" aria-labelledby="bundle-heading">
        <div className="wrap-wide">
          <p className="section-heading" id="bundle-heading">
            Bundle Includes
          </p>
          <ul className="pillars-grid three list-none p-0 m-0">
            {bundleCaves.map((cave) =>
              cave ? (
                <li key={cave.id}>
                  <Link href={`/caves/${cave.id}`} className="stage-card">
                    {cave.image ? (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img
                        src={cave.image}
                        alt=""
                        className="card-cover"
                      />
                    ) : null}
                    <div className="card-body">
                      <h2>{cave.title}</h2>
                      {cave.subtitle ? (
                        <p className="!mt-1 italic font-serif text-[var(--ink-2)] !text-[0.85rem]">
                          {cave.subtitle}
                        </p>
                      ) : null}
                      {cave.tagline ? <p>{cave.tagline}</p> : null}
                      {typeof cave.price_usd === "number" ? (
                        <p className="price-tag !mt-3 !text-[0.95rem]">
                          ${cave.price_usd.toFixed(2)}
                        </p>
                      ) : null}
                      <span className="stage-link">Explore →</span>
                    </div>
                  </Link>
                </li>
              ) : null
            )}
          </ul>
          <div className="mt-8 text-center">
            <a
              href={SHOP_URL}
              className="btn-primary"
              target="_blank"
              rel="noopener noreferrer"
            >
              Get the Experience
            </a>
          </div>
        </div>
      </section>

      {/* Shadow Ledger */}
      <section className="section-block" aria-labelledby="ledger-heading">
        <div className="wrap-wide feature-strip">
          <div>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src="/brand/shadow-ledger-notion.jpg"
              alt=""
              className="banner-image"
            />
          </div>
          <div>
            <p className="section-heading" id="ledger-heading">
              Shadow Ledger
            </p>
            <h2 className="product-title !text-[1.35rem]">
              A shadow-work operating system
            </h2>
            <p className="lede mt-4 !max-w-none">
              Log triggers, map projections, spot recurring archetypal
              patterns, and turn reactivity into integration.
            </p>
            <div className="btn-row mt-6">
              <Link href="/ledger" className="btn-primary">
                Open the Ledger
              </Link>
              <a
                href={SHOP_URL}
                className="btn-secondary"
                target="_blank"
                rel="noopener noreferrer"
              >
                Buy Now
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Mirror + Wisdom */}
      <section className="section-block" aria-label="More paths">
        <div className="wrap-wide pillars-grid">
          <Link href="/mirror" className="stage-card">
            <div className="card-body">
              <p className="meta-label">Path</p>
              <h2 className="!mt-2">Conscious Mirror</h2>
              <p>
                A quiet structure for self-reflection — intake questions and
                reading sections drawn from the teachings.
              </p>
              <span className="stage-link">Enter the Mirror →</span>
            </div>
          </Link>
          <Link href="/wisdom" className="stage-card">
            <div className="card-body">
              <p className="meta-label">Path</p>
              <h2 className="!mt-2">Wisdom Drop</h2>
              <p>
                A rotating well of Laws of the Universe and Ageless Truths —
                brief, precise, meant to be lived with.
              </p>
              <span className="stage-link">Open Wisdom →</span>
            </div>
          </Link>
        </div>
      </section>

      {/* All caves teaser */}
      <section className="section-block" aria-labelledby="caves-all">
        <div className="wrap-wide text-center">
          <p className="section-heading" id="caves-all">
            The Caves
          </p>
          <h2 className="product-title !normal-case !tracking-[0.06em]">
            Four chambers. Enter where you are.
          </h2>
          <p className="lede mt-4 mx-auto">
            Desire, Identity, Silence, and Control — guided philosophical
            experiences created to reveal what quietly shapes how you think,
            want, and see yourself.
          </p>
          <div className="mt-8">
            <Link href="/caves" className="btn-primary">
              View All Caves
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}
