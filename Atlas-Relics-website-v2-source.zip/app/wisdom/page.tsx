import { PageShell } from "@/components/PageShell";
import { wisdomEntries } from "@/lib/content";
import { SHOP_URL, SUBSTACK_URL } from "@/lib/types";

export const metadata = {
  title: "Wisdom Drop",
};

export default function WisdomPage() {
  const ready = wisdomEntries.filter((e) => e.status === "confirmed" && e.text);
  const pending = wisdomEntries.filter(
    (e) => !(e.status === "confirmed" && e.text)
  );

  return (
    <PageShell
      title="Wisdom Drop"
      subtitle="Brief entries drawn from Laws of the Universe and Ageless Truths — meant for daily rotation and quiet attention."
    >
      <div className="btn-row mb-10">
        <a
          href={SUBSTACK_URL}
          className="btn-primary"
          target="_blank"
          rel="noopener noreferrer"
        >
          Read on Substack
        </a>
        <a
          href={SHOP_URL}
          className="btn-secondary"
          target="_blank"
          rel="noopener noreferrer"
        >
          Visit Shop
        </a>
      </div>

      {ready.length > 0 ? (
        <ul className="list-none space-y-4 p-0 m-0">
          {ready.map((entry) => (
            <li key={entry.id} className="pattern-section">
              <p className="meta-label">{entry.source}</p>
              {entry.text ? (
                <p className="mt-3 font-serif text-lg leading-relaxed text-[var(--ink-0)]">
                  {entry.text}
                </p>
              ) : null}
              {entry.reflection_line ? (
                <p className="mt-3 text-sm muted">{entry.reflection_line}</p>
              ) : null}
              {entry.theme_tag ? (
                <p className="meta-label mt-3">{entry.theme_tag}</p>
              ) : null}
            </li>
          ))}
        </ul>
      ) : null}

      {pending.length > 0 ? (
        <div className={`${ready.length ? "mt-10" : ""} pattern-section`}>
          <h2>More drops on the way</h2>
          <p className="mt-3 text-sm text-[var(--ink-1)] leading-relaxed">
            Additional Laws of the Universe and Ageless Truths entries rotate
            through Substack and the shop. Check back — or follow the feed for
            the next drop.
          </p>
          <ul className="mt-4 space-y-1 text-sm muted list-none p-0">
            {pending.map((entry) => (
              <li key={entry.id}>
                {entry.source}
                {entry.theme_tag ? ` · ${entry.theme_tag}` : ""}
              </li>
            ))}
          </ul>
        </div>
      ) : null}
    </PageShell>
  );
}
