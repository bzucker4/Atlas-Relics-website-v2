import Link from "next/link";
import { notFound } from "next/navigation";
import { PageShell } from "@/components/PageShell";
import {
  archetypes,
  getArchetypeById,
  getPolarityPartner,
  getRitualForArchetype,
} from "@/lib/content";
import { SHOP_URL } from "@/lib/types";

export function generateStaticParams() {
  return archetypes.map((a) => ({ id: a.id }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const arch = getArchetypeById(id);
  return { title: arch?.name ?? "Archetype" };
}

export default async function LedgerDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const arch = getArchetypeById(id);
  if (!arch) notFound();

  const partner = getPolarityPartner(arch);
  const ritual = getRitualForArchetype(arch.id);

  return (
    <PageShell title={arch.name}>
      <div className="mb-8 flex flex-wrap items-center gap-3">
        <Link href="/ledger" className="back-link">
          ← All patterns
        </Link>
      </div>

      <p className="lede mb-8">
        Work this pattern inside the Shadow Ledger — log when it activates,
        map the projection, and choose an integration move.
      </p>

      <div className="btn-row mb-10">
        <a
          href={SHOP_URL}
          className="btn-primary"
          target="_blank"
          rel="noopener noreferrer"
        >
          Get the Ledger
        </a>
      </div>

      <div className="content-grid two">
        <section className="pattern-section">
          <h2>Light expression</h2>
          <p className="mt-3 text-sm leading-relaxed text-[var(--ink-1)]">
            {arch.light_expression ?? (
              <span className="soft-pending">
                Light expression for this pattern will appear as the ledger
                teachings expand.
              </span>
            )}
          </p>
        </section>
        <section className="pattern-section">
          <h2>Shadow expression</h2>
          <p className="mt-3 text-sm leading-relaxed text-[var(--ink-1)]">
            {arch.shadow_expression ?? (
              <span className="soft-pending">
                Shadow expression for this pattern will appear as the ledger
                teachings expand.
              </span>
            )}
          </p>
        </section>
        <section className="pattern-section">
          <h2>Polarity partner</h2>
          {partner ? (
            <p className="mt-3">
              <Link
                href={`/ledger/${partner.id}`}
                className="text-[var(--purple)] hover:text-[var(--ink-0)]"
              >
                {partner.name}
              </Link>
            </p>
          ) : (
            <p className="mt-3 soft-pending text-sm">
              Polarity pairing arrives with the full ledger system.
            </p>
          )}
        </section>
        <section className="pattern-section">
          <h2>Integration ritual</h2>
          {ritual?.text ? (
            <dl className="mt-3 space-y-3 text-sm text-[var(--ink-1)]">
              {ritual.practice_type ? (
                <div>
                  <dt className="meta-label">Practice type</dt>
                  <dd className="mt-1">{ritual.practice_type}</dd>
                </div>
              ) : null}
              <div>
                <dt className="meta-label">Text</dt>
                <dd className="mt-1 whitespace-pre-wrap">{ritual.text}</dd>
              </div>
            </dl>
          ) : (
            <p className="mt-3 soft-pending text-sm">
              Integration moves for this archetype live in the Shadow Ledger
              operating system on the shop.
            </p>
          )}
        </section>
      </div>
    </PageShell>
  );
}
