import Link from "next/link";
import { PageShell } from "@/components/PageShell";
import { archetypes } from "@/lib/content";
import { SHOP_URL } from "@/lib/types";

export const metadata = {
  title: "Shadow Ledger",
};

export default function LedgerPage() {
  return (
    <PageShell
      wide
      title="Shadow Ledger"
      subtitle="A shadow-work operating system: log triggers, map projections, spot recurring archetypal patterns, and turn reactivity into integration."
    >
      <div className="mb-10">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src="/brand/shadow-ledger-notion.jpg"
          alt=""
          className="banner-image"
        />
      </div>

      <div className="pattern-section mb-10">
        <h2>Quick start</h2>
        <ol className="mt-4 list-decimal pl-5 space-y-2 text-sm text-[var(--ink-1)] leading-relaxed">
          <li>Notice a trigger — body, thought, or relational charge.</li>
          <li>Log it: what happened, what you felt, what you projected.</li>
          <li>Name the archetype pattern that showed up (below).</li>
          <li>Choose one integration move — journal, somatic, or dialogue.</li>
          <li>Return later: track what recurs until it softens into clarity.</li>
        </ol>
        <div className="btn-row mt-6">
          <a
            href={SHOP_URL}
            className="btn-primary"
            target="_blank"
            rel="noopener noreferrer"
          >
            Get the Ledger
          </a>
          <a
            href={SHOP_URL}
            className="btn-secondary"
            target="_blank"
            rel="noopener noreferrer"
          >
            Buy Now
          </a>
        </div>
      </div>

      <p className="section-heading">Archetypal patterns</p>
      <ul className="pillars-grid list-none p-0 m-0">
        {archetypes.map((arch) => (
          <li key={arch.id}>
            <Link href={`/ledger/${arch.id}`} className="stage-card">
              <div className="card-body">
                <h2>{arch.name}</h2>
                {arch.light_expression || arch.shadow_expression ? (
                  <dl className="mt-3 space-y-2 text-sm">
                    {arch.light_expression ? (
                      <div>
                        <dt className="meta-label">Light</dt>
                        <dd className="mt-1 text-[var(--ink-1)]">
                          {arch.light_expression}
                        </dd>
                      </div>
                    ) : null}
                    {arch.shadow_expression ? (
                      <div>
                        <dt className="meta-label">Shadow</dt>
                        <dd className="mt-1 text-[var(--ink-1)]">
                          {arch.shadow_expression}
                        </dd>
                      </div>
                    ) : null}
                  </dl>
                ) : (
                  <p>
                    Open this pattern to explore light, shadow, and integration
                    moves as they arrive.
                  </p>
                )}
                <span className="stage-link">Open pattern →</span>
              </div>
            </Link>
          </li>
        ))}
      </ul>
    </PageShell>
  );
}
