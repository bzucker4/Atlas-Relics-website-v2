import Link from "next/link";
import { PageShell } from "@/components/PageShell";
import { caves } from "@/lib/content";
import { SHOP_URL } from "@/lib/types";

export const metadata = {
  title: "The Caves",
};

export default function CavesPage() {
  return (
    <PageShell
      wide
      title="The Caves"
      subtitle="Four guided philosophical experiences. There is no required sequence — enter the chamber that meets you where you are."
    >
      <div className="mb-8 btn-row">
        <a
          href={SHOP_URL}
          className="btn-primary"
          target="_blank"
          rel="noopener noreferrer"
        >
          Get the Experience
        </a>
        <a
          href={SHOP_URL}
          className="btn-secondary"
          target="_blank"
          rel="noopener noreferrer"
        >
          Buy Now
        </a>
      </div>

      <ul className="pillars-grid list-none p-0 m-0">
        {caves.map((cave) => (
          <li key={cave.id}>
            <Link href={`/caves/${cave.id}`} className="stage-card">
              {cave.image ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={cave.image} alt="" className="card-cover" />
              ) : null}
              <div className="card-body">
                <h2>{cave.title}</h2>
                {cave.subtitle ? (
                  <p className="!mt-1 italic font-serif text-[var(--ink-2)] !text-[0.85rem]">
                    {cave.subtitle}
                  </p>
                ) : null}
                {cave.tagline ? <p>{cave.tagline}</p> : null}
                {cave.hook ? (
                  <p className="!mt-3 !text-[var(--ink-0)] font-medium">
                    {cave.hook}
                  </p>
                ) : null}
                {typeof cave.price_usd === "number" ? (
                  <p className="price-tag !mt-4 !text-[0.95rem]">
                    ${cave.price_usd.toFixed(2)}
                  </p>
                ) : null}
                <span className="stage-link">View cave →</span>
              </div>
            </Link>
          </li>
        ))}
      </ul>
    </PageShell>
  );
}
