import Link from "next/link";
import { notFound } from "next/navigation";
import { caves, getCaveById } from "@/lib/content";
import { SHOP_URL, type CavePhaseKey } from "@/lib/types";

const phaseLabels: Record<CavePhaseKey, string> = {
  philosophical_inquiry: "Philosophical inquiry",
  silence: "Silence",
  private_reflection: "Private reflection",
  real_world_experiment: "Real-world experiment",
};

export function generateStaticParams() {
  return caves.map((c) => ({ id: c.id }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const cave = getCaveById(id);
  return { title: cave?.title ?? "Cave" };
}

export default async function CaveDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const cave = getCaveById(id);
  if (!cave) notFound();

  const shopHref = cave.shop_url ?? SHOP_URL;
  const phases = cave.phases;
  const phaseKeys = Object.keys(phaseLabels) as CavePhaseKey[];
  const hasAnyPhaseText = phaseKeys.some((key) => {
    const phase = phases?.[key];
    if (key === "philosophical_inquiry" && phase?.core_question) return true;
    return Boolean(phase?.full_text);
  });

  return (
    <div className="wrap-wide py-12 sm:py-16">
      <Link href="/caves" className="back-link">
        ← All caves
      </Link>

      <div className="product-layout mt-8">
        <div className="product-image-wrap">
          {cave.image ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={cave.image} alt={cave.title} />
          ) : (
            <div className="aspect-square bg-[var(--bg-2)]" />
          )}
        </div>

        <div>
          <h1 className="product-title">{cave.title}</h1>
          {cave.subtitle ? (
            <p className="product-subtitle">{cave.subtitle}</p>
          ) : null}

          {typeof cave.price_usd === "number" ? (
            <p className="price-tag mt-5">${cave.price_usd.toFixed(2)}</p>
          ) : null}

          {cave.tagline ? (
            <p className="mt-5 text-[var(--ink-1)] leading-relaxed">
              {cave.tagline}
            </p>
          ) : null}

          {cave.hook ? (
            <p className="mt-4 text-lg font-medium text-[var(--ink-0)] leading-relaxed">
              {cave.hook}
            </p>
          ) : null}

          {cave.short_description ? (
            <p className="mt-4 text-[var(--ink-1)] leading-relaxed">
              {cave.short_description}
            </p>
          ) : null}

          <div className="btn-row mt-8">
            <a
              href={shopHref}
              className="btn-primary"
              target="_blank"
              rel="noopener noreferrer"
            >
              Begin Your Descent
            </a>
            <a
              href={shopHref}
              className="btn-secondary"
              target="_blank"
              rel="noopener noreferrer"
            >
              Buy Now
            </a>
          </div>

          <p className="mt-4 text-xs muted">
            Experiences are purchased at{" "}
            <a
              href={SHOP_URL}
              className="text-[var(--purple)]"
              target="_blank"
              rel="noopener noreferrer"
            >
              atlas-relics.com
            </a>
            .
          </p>
        </div>
      </div>

      {hasAnyPhaseText ? (
        <div className="mt-14 space-y-4">
          <p className="section-heading">Inside this cave</p>
          {phaseKeys.map((key) => {
            const phase = phases?.[key];
            const core =
              key === "philosophical_inquiry"
                ? phase?.core_question ?? null
                : null;
            const full = phase?.full_text ?? null;
            if (!core && !full) return null;

            return (
              <section key={key} className="pattern-section">
                <h2>{phaseLabels[key]}</h2>
                {core ? (
                  <p className="mt-3 text-[var(--ink-0)] leading-relaxed">
                    {core}
                  </p>
                ) : null}
                {full ? (
                  <p className="mt-3 whitespace-pre-wrap text-sm leading-relaxed text-[var(--ink-1)]">
                    {full}
                  </p>
                ) : null}
              </section>
            );
          })}
        </div>
      ) : null}
    </div>
  );
}
