import { PageShell } from "@/components/PageShell";
import { mirrorStructure } from "@/lib/content";
import { SHOP_URL } from "@/lib/types";

export const metadata = {
  title: "Conscious Mirror",
};

export default function MirrorPage() {
  return (
    <PageShell
      title="Conscious Mirror"
      subtitle="A structured path for self-reflection. The intake flow and reading sections below are offered as a map — quiet inquiry, not a machine."
    >
      <section className="disclaimer-box mb-10">
        <p className="meta-label">A note before you begin</p>
        <p className="mt-3 text-sm leading-relaxed text-[var(--ink-0)]">
          {mirrorStructure.required_disclaimer}
        </p>
      </section>

      <div className="btn-row mb-10">
        <a
          href={SHOP_URL}
          className="btn-primary"
          target="_blank"
          rel="noopener noreferrer"
        >
          Visit the Shop
        </a>
      </div>

      <div className="content-grid two">
        <section>
          <h2 className="page-title !text-lg !tracking-[0.08em]">
            Intake questions
          </h2>
          <p className="mt-2 text-sm muted">
            Move through these in order. This page presents the questions for
            contemplation — it does not collect or score answers.
          </p>
          <ol className="mt-6 list-none space-y-4 p-0">
            {mirrorStructure.intake_questions.map((q, i) => (
              <li key={i} className="pattern-section">
                <span className="meta-label">Question {i + 1}</span>
                <p className="mt-2 text-sm leading-relaxed text-[var(--ink-0)]">
                  {q}
                </p>
              </li>
            ))}
          </ol>
        </section>

        <section>
          <h2 className="page-title !text-lg !tracking-[0.08em]">
            Reading sections
          </h2>
          <p className="mt-2 text-sm muted">
            The shape of a completed Mirror reading — sections to hold after the
            inquiry.
          </p>
          <ol className="mt-6 list-none space-y-3 p-0">
            {mirrorStructure.reading_sections.map((s, i) => (
              <li
                key={i}
                className="pattern-section flex gap-3 !py-3 !px-4"
              >
                <span className="text-sm font-semibold text-[var(--purple)]">
                  {String(i + 1).padStart(2, "0")}
                </span>
                <span className="text-sm leading-relaxed text-[var(--ink-0)]">
                  {s}
                </span>
              </li>
            ))}
          </ol>
        </section>
      </div>
    </PageShell>
  );
}
