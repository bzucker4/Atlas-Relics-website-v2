import type { ContentStatus } from "@/lib/types";

export function StatusBadge({ status }: { status: ContentStatus | string }) {
  const isReady = status === "confirmed";
  return (
    <span
      className={`status-badge${isReady ? " is-ready" : ""}`}
      title={isReady ? "Available" : "In progress"}
    >
      {isReady ? "available" : "in progress"}
    </span>
  );
}
