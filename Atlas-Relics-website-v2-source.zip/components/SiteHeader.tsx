import Link from "next/link";
import { SHOP_URL } from "@/lib/types";

const nav = [
  { href: "/caves", label: "Caves" },
  { href: "/ledger", label: "Ledger" },
  { href: "/mirror", label: "Mirror" },
  { href: "/wisdom", label: "Wisdom" },
  { href: SHOP_URL, label: "Shop", external: true },
];

export function SiteHeader() {
  return (
    <header className="site-header">
      <div className="wrap-wide flex items-center justify-between gap-4 py-3.5">
        <Link href="/" className="brand-mark">
          <span className="ar-mono" aria-hidden="true">
            <span className="ar-a">A</span>
            <span className="ar-r">R</span>
          </span>
          <span className="hidden sm:inline">Atlas Relics</span>
        </Link>
        <nav className="flex flex-wrap items-center justify-end gap-0.5 sm:gap-1">
          {nav.map((item) =>
            item.external ? (
              <a
                key={item.href}
                href={item.href}
                className="nav-link"
                target="_blank"
                rel="noopener noreferrer"
              >
                {item.label}
              </a>
            ) : (
              <Link key={item.href} href={item.href} className="nav-link">
                {item.label}
              </Link>
            )
          )}
        </nav>
      </div>
    </header>
  );
}
