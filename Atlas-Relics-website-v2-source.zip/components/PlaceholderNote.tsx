export function PlaceholderNote({
  note,
  children,
}: {
  note?: string | null;
  children?: React.ReactNode;
}) {
  return (
    <aside className="callout">
      <strong>Coming soon</strong>
      <p>
        {note ??
          "Deeper teaching text for this section is still arriving. The experience itself lives in the shop."}
      </p>
      {children ? <div className="mt-2 muted">{children}</div> : null}
    </aside>
  );
}
