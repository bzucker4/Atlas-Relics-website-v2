import Link from "next/link";
import { SHOP_URL, SUBSTACK_URL } from "@/lib/types";

export function SiteFooter() {
  return (
    <footer className="site-footer mt-auto">
      <div className="wrap-wide flex flex-col gap-5 py-10 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <p className="text-[var(--ink-1)] font-semibold tracking-wide uppercase text-sm">
            Atlas Relics · Atlas Reed
          </p>
          <p className="mt-1.5 text-sm muted max-w-sm">
            Guided philosophical experiences for the inner work — caves,
            shadow practice, and quiet inquiry.
          </p>
        </div>
        <div className="flex flex-wrap gap-x-5 gap-y-2 text-sm">
          <Link href="/caves">Caves</Link>
          <Link href="/ledger">Ledger</Link>
          <Link href="/mirror">Mirror</Link>
          <Link href="/wisdom">Wisdom</Link>
          <a href={SHOP_URL} target="_blank" rel="noopener noreferrer">
            Shop
          </a>
          <a href={SUBSTACK_URL} target="_blank" rel="noopener noreferrer">
            Substack
          </a>
        </div>
      </div>
    </footer>
  );
}
