/** Content status from the Atlas Relics content pack */
export type ContentStatus = "confirmed" | "needs_content";

export type CavePhaseKey =
  | "philosophical_inquiry"
  | "silence"
  | "private_reflection"
  | "real_world_experiment";

export interface CavePhase {
  core_question?: string | null;
  full_text: string | null;
}

export interface Cave {
  id: string;
  title: string;
  subtitle?: string;
  tagline?: string;
  hook?: string;
  short_description?: string;
  image?: string;
  shop_url?: string;
  price_usd?: number;
  theme_tag?: string;
  status: ContentStatus;
  phases?: {
    philosophical_inquiry?: CavePhase;
    silence?: CavePhase;
    private_reflection?: CavePhase;
    real_world_experiment?: CavePhase;
  };
  _note?: string;
}

export interface Archetype {
  id: string;
  name: string;
  light_expression: string | null;
  shadow_expression: string | null;
  polarity_partner_id: string | null;
  status: ContentStatus;
}

export type PracticeType =
  | "journaling_prompt"
  | "somatic_practice"
  | "dialogue_exercise"
  | null;

export interface IntegrationRitual {
  id: string;
  archetype_id: string;
  practice_type: PracticeType;
  text: string | null;
  status: ContentStatus;
}

export type WisdomSource =
  | "Laws of the Universe"
  | "Ageless Truths"
  | "The Great Shift"
  | "other";

export interface WisdomEntry {
  id: string;
  source: WisdomSource | string;
  text: string | null;
  reflection_line: string | null;
  theme_tag: string | null;
  status: ContentStatus;
  _note?: string;
}

export interface MirrorReadingStructure {
  _status?: string;
  _source?: string;
  intake_questions: string[];
  reading_sections: string[];
  required_disclaimer: string;
  _build_note?: string;
}

export const SHOP_URL = "https://atlas-relics.com";
export const SUBSTACK_URL = "https://atlasrelics95.substack.com/";
