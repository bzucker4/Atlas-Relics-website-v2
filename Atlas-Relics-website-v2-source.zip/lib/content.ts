import cavesData from "@/content/data/caves.json";
import archetypesData from "@/content/data/archetypes.json";
import ledgerPromptsData from "@/content/data/ledger_prompts.json";
import wisdomEntriesData from "@/content/data/wisdom_entries.json";
import mirrorData from "@/content/data/mirror_reading_structure.json";
import type {
  Cave,
  Archetype,
  IntegrationRitual,
  WisdomEntry,
  MirrorReadingStructure,
} from "./types";

export const caves = cavesData as Cave[];
export const archetypes = archetypesData as Archetype[];
export const ledgerPrompts = ledgerPromptsData as IntegrationRitual[];
export const wisdomEntries = wisdomEntriesData as WisdomEntry[];
export const mirrorStructure = mirrorData as MirrorReadingStructure;

export function getCaveById(id: string): Cave | undefined {
  return caves.find((c) => c.id === id);
}

export function getArchetypeById(id: string): Archetype | undefined {
  return archetypes.find((a) => a.id === id);
}

export function getRitualForArchetype(
  archetypeId: string
): IntegrationRitual | undefined {
  return ledgerPrompts.find((r) => r.archetype_id === archetypeId);
}

export function getPolarityPartner(
  archetype: Archetype
): Archetype | undefined {
  if (!archetype.polarity_partner_id) return undefined;
  return getArchetypeById(archetype.polarity_partner_id);
}
