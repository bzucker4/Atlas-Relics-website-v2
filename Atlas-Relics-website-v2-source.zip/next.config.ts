import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Static HTML for Netlify drag-and-drop / publish-directory deploys.
  // For Git-connected Netlify builds you can remove this and use the
  // automatic @netlify/next runtime instead (see netlify.toml).
  output: "export",
  images: { unoptimized: true },
};

export default nextConfig;
